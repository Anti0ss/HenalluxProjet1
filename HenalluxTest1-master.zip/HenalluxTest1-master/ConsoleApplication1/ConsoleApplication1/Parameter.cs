﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public static class Parameter
    {
        public const int MAXACTIVITIES = 10;

        public enum enumEvaluation { R = 1, S, T};

        
    }
}
